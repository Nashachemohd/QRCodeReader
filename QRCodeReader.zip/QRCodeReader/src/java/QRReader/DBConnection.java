package QRReader;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class DBConnection {
    private static final String URL="jdbc:mysql://localhost:3306/sas";
    private static final String DRIVERNAME = "com.mysql.jdbc.Driver";
    private static final String USERNAME = "root"; //root adalah super user. jangan guna untuk app.senang untuk hack
    private static final String PASSWORD = "admin";
    private static Connection conn;
    
    public static Connection getConnection(){
        //try catch penting untuk tahu apa error dia yang timbul.
        try {
            Class.forName(DRIVERNAME);
            //satu lagi try untuk load driver itu. 
            try{
                conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            } 
            catch (SQLException ex) {
                System.out.print("The error is "+ex.getMessage());
            }
        } 
        //andai kata driver ini tidak dijumpai, maka kita nak catch, supaya system tak crash
        catch (ClassNotFoundException ex) {
            System.out.print(ex.getMessage());
        }
    return conn;
    }
    
}
