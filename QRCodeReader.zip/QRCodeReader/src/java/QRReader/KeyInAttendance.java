/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package QRReader;

/**
 *
 * @author user
 */
public class KeyInAttendance {
    private String studID;
    private String studPW;
    private String classID;
    private String attStatus;

    public String getClassID() {
        return classID;
    }

    public void setClassID(String classID) {
        this.classID = classID;
    }    

    public String getStudID() {
        return studID;
    }

    public void setStudID(String studID) {
        this.studID = studID;
    }

    public String getStudPW() {
        return studPW;
    }

    public void setStudPW(String studPW) {
        this.studPW = studPW;
    }









    public String getAttStatus() {
        return attStatus;
    }

    public void setAttStatus(String attStatus) {
        this.attStatus = attStatus;
    }
    
    
    
}
