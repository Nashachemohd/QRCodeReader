/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package QRReader;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;

/**
 *
 * @author user
 */
public class KeyInAttendanceDAO {

    private final Connection connection;
    private int result;

    public KeyInAttendanceDAO() {
        connection = DBConnection.getConnection();
    }

    public boolean studVerification(KeyInAttendance att) throws SQLException {

        boolean status = false;

        try {
            String mySqlQuery = ("select * from student "
                    + "where studID=? and studPW=?");
            PreparedStatement ps = connection.prepareStatement(mySqlQuery);
            ps.setString(1, att.getStudID());
            ps.setString(2, att.getStudPW());
            ResultSet rs = ps.executeQuery(mySqlQuery);
            status = rs.next();
        } catch (SQLException ex) {
            System.out.print(ex.getMessage());
        }
        
        
        finally {
            connection.close();
        }
        return status;
    }

    public Attendance retrieveAtt(String studentID) throws SQLException {
        ResultSet rs = null;
        Attendance att = new Attendance();

        try {
            String mySqlQuery = "select studID,cID,attDate,attTime from attendance"
                    + "where studID=?";
            PreparedStatement ps = connection.prepareStatement(mySqlQuery);
            ps.setString(1, studentID);
            rs = ps.executeQuery(mySqlQuery);

            if (rs.next()) {
                att = new Attendance();
                att.setStudID(rs.getString(1));
                att.setClassID(rs.getString(2));
                att.setAttDate(rs.getString(3));
                att.setAttTime(rs.getString(4));

            }

        } catch (SQLException ex) {
            System.out.print(ex.getMessage());
        } finally {
            if (rs != null) {
                rs.close();
            }
            connection.close();
        }
        return att;
    }

    //to insert into the database (keyattendance table) /search log in details
    /*public void addKeyInAttendance (KeyInAttendance studentatt) throws SQLException{
        
        try {
            String mySqlQuery = "insert into keyattendance(studID,studPW) values (?,?)";
            
            PreparedStatement myPS = connection.prepareStatement(mySqlQuery);
            myPS.setString(1, studentatt.getStudID());
            myPS.setString(2, studentatt.getStudPW());
            result=myPS.executeUpdate();
            
        } catch (SQLException e) {
            System.out.print("Exception is "+e);
        }
        finally{
            connection.close();
        }
    }*/
    //to insert into the database (Attendance table)
    public void addAttendance(KeyInAttendance studentatt) throws SQLException {

        DateTimeFormatter formatDate = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter formatTime = DateTimeFormatter.ofPattern("HH:mm:ss");

        LocalDate myDate = LocalDate.now();
        LocalTime myTime = LocalTime.now();

        String stringDate = myDate.format(formatDate);
        String stringTime = myTime.format(formatTime);

        try {
            String mySqlQuery = "insert into attendance(studID,cID,attDate,attTime)"
                    + "values (?,?,?,?)";

            PreparedStatement myPS = connection.prepareStatement(mySqlQuery);
            myPS.setString(1, studentatt.getStudID());
            myPS.setString(2, studentatt.getClassID());
            myPS.setString(3, stringDate);
            myPS.setString(4, stringTime);
            result = myPS.executeUpdate();

        } catch (SQLException e) {
            System.out.print("Exception is " + e);
        } finally {
            connection.close();
        }

    }

    //retrieve all attribute from keyAttendance
    public List<KeyInAttendance> retrieveAllAttendance() throws SQLException {
        List<KeyInAttendance> attendanceAll = new ArrayList<KeyInAttendance>();
        KeyInAttendance studentatt;

        try {
            Statement myStatement = connection.createStatement();
            String myQuery = "select*from keyattendance";
            ResultSet myRS = myStatement.executeQuery(myQuery);

            while (myRS.next()) {
                studentatt = new KeyInAttendance();
                studentatt.setStudID(myRS.getString(1));
                studentatt.setStudPW(myRS.getString(2));

                attendanceAll.add(studentatt);
            }
        } catch (SQLException e) {
            System.out.print("Exception is " + e);
        } finally {
            connection.close();
        }
        return attendanceAll;
    }

    //retrive all courseName from Lectenrollment
}
