/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package QRReader;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author user
 */
public class QRReaderController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        String cmd = request.getParameter("command");

        if (cmd != null) {
            switch (cmd) {
                case "submitAttendance":
                    searchName(request, response);
                    break;
                case "tryAgain":
                    response.sendRedirect(request.getContextPath() + "/index.jsp");
                    break;
            }
        } else {
            response.sendRedirect(request.getContextPath() + "/index.jsp");
        }
    }

    public void searchName(HttpServletRequest req, HttpServletResponse resp) throws SQLException, ServletException, IOException {
        String studID = req.getParameter("studID");
        String studPw = req.getParameter("studPW");
        String cID = req.getParameter("classID");

        KeyInAttendance keyIn = new KeyInAttendance();
        keyIn.setStudID(studID);
        keyIn.setStudPW(studPw);
        keyIn.setClassID(cID);
        //String studValidate = k.studVerification(keyIn);

        /*if (k.studVerification(keyIn)) {
            saveAttendance(keyIn);
            req.setAttribute("Success", keyIn);
            RequestDispatcher rd = req.getRequestDispatcher("success.jsp");
            rd.forward(req, resp);
        } else {
            RequestDispatcher rd = req.getRequestDispatcher("failed.jsp");
            rd.forward(req, resp);

        }*/
        Connection conn;
        conn = DBConnection.getConnection();
        try {

            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("select * from student where studID='" + studID + "' and studPW='" + studPw + "'");
            if (rs.next()) {
                saveAttendance(keyIn);
                resp.sendRedirect("success.jsp");
            } else {
                resp.sendRedirect("failed.jsp");
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            conn.close();
        }
    }

    private void saveAttendance(KeyInAttendance attendance) throws SQLException {
        KeyInAttendanceDAO k2 = new KeyInAttendanceDAO();
        k2.addAttendance(attendance);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(QRReaderController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(QRReaderController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
